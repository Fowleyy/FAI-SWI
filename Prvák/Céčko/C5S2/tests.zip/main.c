#include <stdio.h>
#include ".\lib\lib.h"

int main() {
    int n = 1189;

    int factor = polard(n);

    printf("Jeden z faktoru: %d\n", factor);
    printf("Druhý faktor: %d\n", n / factor);

    return 0;
}
