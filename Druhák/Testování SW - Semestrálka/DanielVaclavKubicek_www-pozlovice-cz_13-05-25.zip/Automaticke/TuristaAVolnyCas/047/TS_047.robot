*** Settings ***
Library  SeleniumLibrary  run_on_failure=Nothing
Resource  Browsers.robot
Resource  URLs.robot
Resource  Buttons.robot
Resource  Values.robot
Resource  Inputs.robot
Resource  Keywords.robot

*** Test Cases ***
Pre-conditions
    Otevri Prohlizec Jdi na URL a Zkontroluj  ${Browser_Chrome}  ${URL_MainPage}  ${Button_Turista}

Ověření dostupnosti sekce „Sportoviště“
    Kontroluj  ${Button_Turista}  ${URL_Finish}  ${Button_Sportoviste}  ${URL_Finish2}  ${Button_Rezervace}  ${URL_Finish3}

Post-conditions
    Close Browser

