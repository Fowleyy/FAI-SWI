/*!
 * \file       vector.c
 * \author     Horak, Jurena
 * \date       2019.6
 * \brief      Implementation of function.h header file
 * ******************************************
 * \attention
 * &copy; Copyright (c) 2022 FAI UTB. All rights reserved.
 *
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 */
/* Includes --------------------------------------------------------------------------------------*/
#include "vector.h"
#include <stdlib.h>
#include <string.h>
#include <mymalloc.h>

/* Private types ---------------------------------------------------------------------------------*/
/* Private macros --------------------------------------------------------------------------------*/
#define UNUSED(x) (void)x

/* Private variables -----------------------------------------------------------------------------*/
/* Private function declarations -----------------------------------------------------------------*/
/* Exported functions definitions ----------------------------------------------------------------*/
Vector_t *Vector_Create(size_t initial_size, size_t alloc_step)
{
    if (initial_size == 0 || alloc_step == 0)
        return NULL;

    Vector_t *vector = (Vector_t *)myMalloc(sizeof(Vector_t));
    if (!vector)
        return NULL;

    vector->items = (Vector_DataType_t *)myMalloc(sizeof(Vector_DataType_t) * initial_size);
    if (!vector->items) {
        free(vector);
        return NULL;
    }

    vector->size = initial_size;
    vector->next = vector->items;
    vector->alloc_step = alloc_step;

    return vector;
}

Vector_t *Vector_Copy(const Vector_t *const original)
{
    if (!original)
        return NULL;

    Vector_t *copy = (Vector_t *)myMalloc(sizeof(Vector_t));
    if (!copy)
        return NULL;

    size_t length = Vector_Length(original);
    size_t capacity = original->size;

    copy->items = (Vector_DataType_t *)myMalloc(sizeof(Vector_DataType_t) * capacity);
    if (!copy->items) {
        free(copy);
        return NULL;
    }

    memcpy(copy->items, original->items, sizeof(Vector_DataType_t) * length);
    copy->size = capacity;
    copy->next = copy->items + length;
    copy->alloc_step = original->alloc_step;

    return copy;
}

void Vector_Clear(Vector_t *const vector)
{
    if (!vector)
        return;

    vector->next = vector->items;
}

size_t Vector_Length(const Vector_t *const vector)
{
    if (!vector)
        return SIZE_MAX;

    return (size_t)(vector->next - vector->items);
}

bool Vector_At(const Vector_t *const vector, size_t position, Vector_DataType_t *const value)
{
    if (!vector || !value || position >= Vector_Length(vector))
        return false;

    *value = vector->items[position];
    return true;
}

bool Vector_Remove(Vector_t *const vector, size_t position)
{
    if (!vector || position >= Vector_Length(vector))
        return false;

    size_t length = Vector_Length(vector);
    memmove(&vector->items[position], &vector->items[position + 1],
            sizeof(Vector_DataType_t) * (length - position - 1));

    vector->next--;
    return true;
}

void Vector_Append(Vector_t *const vector, Vector_DataType_t value)
{
    if (!vector)
        return;

    size_t length = Vector_Length(vector);
    if (length >= vector->size) {
        size_t new_size = vector->size + vector->alloc_step;
        Vector_DataType_t *new_items = (Vector_DataType_t *)myRealloc(vector->items, sizeof(Vector_DataType_t) * new_size);
        if (!new_items)
            return;

        vector->items = new_items;
        vector->size = new_size;
        vector->next = vector->items + length;
    }

    *vector->next = value;
    vector->next++;
}

bool Vector_Contains(const Vector_t *const vector, Vector_DataType_t value)
{
    if (!vector)
        return false;

    size_t length = Vector_Length(vector);
    for (size_t i = 0; i < length; i++) {
        if (vector->items[i] == value)
            return true;
    }

    return false;
}

size_t Vector_IndexOf(const Vector_t *const vector, Vector_DataType_t value, size_t from)
{
    if (!vector || from >= Vector_Length(vector))
        return SIZE_MAX;

    size_t length = Vector_Length(vector);
    for (size_t i = from; i < length; i++) {
        if (vector->items[i] == value)
            return i;
    }

    return SIZE_MAX;
}

void Vector_Fill(const Vector_t *const vector,
                 Vector_DataType_t value,
                 size_t start_position,
                 size_t end_position)
{
    if (!vector)
        return;

    size_t length = Vector_Length(vector);
    if (start_position >= length)
        return;

    if (end_position >= length)
        end_position = length - 1;

    for (size_t i = start_position; i <= end_position; i++) {
        vector->items[i] = value;
    }
}

void Vector_Destroy(Vector_t **const vector)
{
    if (!vector || !*vector)
        return;

    myFree((*vector)->items);
    myFree(*vector);
    *vector = NULL;
}

/* Private function definitions ------------------------------------------------------------------*/