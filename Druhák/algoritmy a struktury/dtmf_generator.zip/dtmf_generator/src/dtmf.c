/*!
 * \file       dtmf.c
 * \author     Ondřej Ševčík
 * \date       9/2019
 * \brief      Implementation of DTMF generator module
 * **************************************************************
 * \attention
 * &copy; Copyright (c) 2022 FAI UTB. All rights reserved.
 *
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 */

/* Includes --------------------------------------------------------------------------------------*/
#include "dtmf.h"
#include "wavfile.h"
#include "vector.h"
#include <math.h>
#include <stdbool.h>
#include <ctype.h>
/* Private types ---------------------------------------------------------------------------------*/
/* Private macros --------------------------------------------------------------------------------*/
#define VOLUME 1000

#define DURATION_MS 500
#define N_SAMPLES 4000
/* Private variables -----------------------------------------------------------------------------*/
static double mSamplesLUT[WAVFILE_SAMPLES_PER_SECOND];

/* Private function declarations -----------------------------------------------------------------*/
/* Exported functions definitions ----------------------------------------------------------------*/
/* Private function definitions ------------------------------------------------------------------*/

/* Function definition ----------------------------------------------------- */
bool DTMF_Generate(Vector_t *vector, char symbol)
{
  static bool initialized = false;
  if (!initialized) {
    for (int i = 0; i < WAVFILE_SAMPLES_PER_SECOND; i++) {
      mSamplesLUT[i] = (double)i / WAVFILE_SAMPLES_PER_SECOND * 2 * M_PI;
    }
    initialized = true;
  }

  double f_low = 0.0, f_high = 0.0;

  symbol = toupper(symbol);
  /* Map the symbol to its corresponding low and high frequencies */
  switch (symbol) {
    case '1': f_low = 697.0; f_high = 1209.0; break;
    case '2': f_low = 697.0; f_high = 1336.0; break;
    case '3': f_low = 697.0; f_high = 1477.0; break;
    case 'A': f_low = 697.0; f_high = 1633.0; break;
    case '4': f_low = 770.0; f_high = 1209.0; break;
    case '5': f_low = 770.0; f_high = 1336.0; break;
    case '6': f_low = 770.0; f_high = 1477.0; break;
    case 'B': f_low = 770.0; f_high = 1633.0; break;
    case '7': f_low = 852.0; f_high = 1209.0; break;
    case '8': f_low = 852.0; f_high = 1336.0; break;
    case '9': f_low = 852.0; f_high = 1477.0; break;
    case 'C': f_low = 852.0; f_high = 1633.0; break;
    case '*': f_low = 941.0; f_high = 1209.0; break;
    case '0': f_low = 941.0; f_high = 1336.0; break;
    case '#': f_low = 941.0; f_high = 1477.0; break;
    case 'D': f_low = 941.0; f_high = 1633.0; break;
    case ' ': f_low = 0.0; f_high = 0.0; break;
    default:
      /* Invalid symbol */
        return false;
  }

  for (int i = 0; i < WAVFILE_SAMPLES_PER_SECOND; i++) {
    double angle = mSamplesLUT[i];
    double sample = VOLUME * (
        sin(angle * f_low) +
        sin(angle * f_high)
    );

    Vector_DataType_t sample_value = (Vector_DataType_t)sample;
    Vector_Append(vector, sample_value);
  }

  return true;
}
