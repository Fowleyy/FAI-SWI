var indexSectionsWithContent =
{
  0: "adimnsv",
  1: "v",
  2: "dmv",
  3: "dv",
  4: "ains",
  5: "v",
  6: "dv",
  7: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "groups",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Modules",
  7: "Pages"
};

