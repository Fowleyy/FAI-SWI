var searchData=
[
  ['vector_5fdatatype_5ft_50',['Vector_DataType_t',['../group__vector.html#gaff7fe628a1825f962c1cdab1511221ea',1,'vector.h']]]
];
