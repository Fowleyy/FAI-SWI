var searchData=
[
  ['dtmf_20generátor_20tónů_53',['DTMF generátor tónů',['../index.html',1,'']]]
];
