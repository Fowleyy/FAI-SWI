var searchData=
[
  ['next_8',['next',['../struct_vector__t.html#a37778f406f88661a31c066daac7cd446',1,'Vector_t']]]
];
