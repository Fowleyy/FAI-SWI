var struct_vector__t =
[
    [ "alloc_step", "struct_vector__t.html#a63d496d061068a71eaa109865e022677", null ],
    [ "items", "struct_vector__t.html#a2078e01a391353ea4a6276983e2fbffb", null ],
    [ "next", "struct_vector__t.html#a37778f406f88661a31c066daac7cd446", null ],
    [ "size", "struct_vector__t.html#a854352f53b148adc24983a58a1866d66", null ]
];