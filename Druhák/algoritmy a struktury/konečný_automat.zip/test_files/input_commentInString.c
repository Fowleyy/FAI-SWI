#include <stdio.h>

int main( int argc, char **argv )
{
	const char* text2 = "This is a // comment inside text";

	return 0;
}
