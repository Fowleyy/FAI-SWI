/* This is a test file for Mealy machine removing comments.
This particular comment is a multi
line
one
*/

#include <stdio.h>

int main( int argc, char **argv )
{
	return 0;
}
