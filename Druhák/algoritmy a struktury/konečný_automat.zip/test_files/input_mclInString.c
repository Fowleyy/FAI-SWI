#include <stdio.h>

int main( int argc, char **argv )
{

	const char* text = "This is a /* comment */ inside 'text'";

	return 0;
}
