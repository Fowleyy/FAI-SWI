var searchData=
[
  ['zpracování_20textů_20_2d_20konečný_20automat_6',['Zpracování textů - konečný automat',['../index.html',1,'']]]
];
