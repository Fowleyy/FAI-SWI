var searchData=
[
  ['config_0',['Config',['../struct_config.html',1,'']]]
];
