var struct_config =
[
    [ "input", "struct_config.html#abfae665d56d61e1c21831bec369abd34", null ],
    [ "output", "struct_config.html#ab41bf19330e50c3c7bf3544c53f30971", null ]
];