var annotated_dup =
[
    [ "Data_t", "struct_data__t.html", "struct_data__t" ],
    [ "tDijkstra", "structt_dijkstra.html", "structt_dijkstra" ],
    [ "tHeap", "structt_heap.html", "structt_heap" ]
];