var modules =
[
    [ "Data", "group__data.html", "group__data" ],
    [ "Dijkstra algorithm", "group__dijkstra.html", "group__dijkstra" ],
    [ "Heap", "group__heap.html", "group__heap" ]
];