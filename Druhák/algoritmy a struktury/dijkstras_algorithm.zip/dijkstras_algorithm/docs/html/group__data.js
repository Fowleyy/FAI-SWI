var group__data =
[
    [ "Data_t", "struct_data__t.html", [
      [ "distanceToCity", "struct_data__t.html#a24b063f4ac5ebfb521ada5a58cd24169", null ],
      [ "id", "struct_data__t.html#a50d6aa2bf63622320919cf7b4a294939", null ],
      [ "name", "struct_data__t.html#a8e03167ce04350be901b028cc4cf1ce1", null ],
      [ "roadCityIndex", "struct_data__t.html#adf1a459d3e2c87a60dfdfc18bdde93a9", null ],
      [ "roadLength", "struct_data__t.html#a982efae362787df91211d6d6ba230092", null ]
    ] ],
    [ "Data_Cmp", "group__data.html#ga1dc4359e044d1e60c104ede24ab6fcae", null ],
    [ "Data_Print", "group__data.html#ga8114b2217f1ee5e22d3da3f3d1a3b63a", null ]
];