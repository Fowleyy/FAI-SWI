var searchData=
[
  ['name_40',['name',['../struct_data__t.html#a8e03167ce04350be901b028cc4cf1ce1',1,'Data_t']]]
];
