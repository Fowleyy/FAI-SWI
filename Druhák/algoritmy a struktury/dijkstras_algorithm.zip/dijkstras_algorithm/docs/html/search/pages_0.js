var searchData=
[
  ['dijkstrův_20algoritmus_20s_20použitím_20haldy_90',['Dijkstrův algoritmus s použitím haldy',['../index.html',1,'']]]
];
