var searchData=
[
  ['roadcityindex_84',['roadCityIndex',['../struct_data__t.html#adf1a459d3e2c87a60dfdfc18bdde93a9',1,'Data_t']]],
  ['roadlength_85',['roadLength',['../struct_data__t.html#a982efae362787df91211d6d6ba230092',1,'Data_t']]]
];
