var searchData=
[
  ['data_87',['Data',['../group__data.html',1,'']]],
  ['dijkstra_20algorithm_88',['Dijkstra algorithm',['../group__dijkstra.html',1,'']]]
];
