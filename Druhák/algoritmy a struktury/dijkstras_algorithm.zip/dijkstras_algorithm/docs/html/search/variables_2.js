var searchData=
[
  ['distances_79',['distances',['../group__dijkstra.html#gaf565f38c1469022268d524adcfa78565',1,'tDijkstra']]],
  ['distancetocity_80',['distanceToCity',['../struct_data__t.html#a24b063f4ac5ebfb521ada5a58cd24169',1,'Data_t']]]
];
