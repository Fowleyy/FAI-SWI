var structt_heap =
[
    [ "array", "structt_heap.html#acf614b8326962d72a866226da9c194d8", null ],
    [ "count", "structt_heap.html#a76d971a3c552bc58ba9f0d5fceae9806", null ],
    [ "maxItems", "structt_heap.html#a70b8bd408f13188120399a39881602db", null ]
];