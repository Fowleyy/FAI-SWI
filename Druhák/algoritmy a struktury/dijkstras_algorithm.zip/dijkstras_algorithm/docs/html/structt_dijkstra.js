var structt_dijkstra =
[
    [ "distances", "group__dijkstra.html#gaf565f38c1469022268d524adcfa78565", null ],
    [ "visited", "group__dijkstra.html#gad083c3c8eed50d1883f59dc6b3c3bb9d", null ]
];