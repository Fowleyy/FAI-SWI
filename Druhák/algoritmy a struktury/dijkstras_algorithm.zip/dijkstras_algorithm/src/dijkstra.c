#include "dijkstra.h"

#include "heap.h"
#include "mymalloc.h"

bool Dijkstra_Init(tDijkstra *dijkstra, unsigned cityCount, unsigned sourceCityID)
{
  if (dijkstra == NULL || cityCount == 0) {
    return false;
  }

  dijkstra->visited = myMalloc(sizeof(bool) * cityCount);
  if (dijkstra->visited == NULL) {
    return false;
  }

  dijkstra->distances = myMalloc(sizeof(unsigned int) * cityCount);
  if (dijkstra->distances == NULL) {
    myFree(dijkstra->visited);
    dijkstra->visited = NULL;
    return false;
  }

  for (unsigned int i = 0; i < cityCount; i++) {
    dijkstra->visited[i] = false;
    dijkstra->distances[i] = INF;
  }

  dijkstra->distances[sourceCityID] = 0;
  return true;
}

void Dijkstra_Destruct(tDijkstra *dijkstra)
{
  if (dijkstra == NULL)
    return;

  myFree(dijkstra->visited);
  dijkstra->visited = NULL;
  myFree(dijkstra->distances);
  dijkstra->distances = NULL;
}

bool Dijkstra_Dist(Data_t *mapHeap,
                   tDijkstra *dijkstra,
                   unsigned sourceCityID,
                   unsigned destination)
{
  if (mapHeap == NULL || dijkstra == NULL || sourceCityID == destination) {
    return false;
  }

  tHeap heap;
  if (Heap_Init(&heap) == false) {
    return false;
  }

  Heap_Insert(&heap, mapHeap[sourceCityID]);
  Data_t city;
  while (!Heap_Empty(heap)) {
    Heap_DeleteMin(&heap, &city);

    if (dijkstra->visited[city.id]) {
      continue;
    }

    for (unsigned i = 0; i < sizeof(city.roadLength) / sizeof(unsigned); i++) {
      unsigned dist = city.roadLength[i] + city.distanceToCity;
      unsigned index = city.roadCityIndex[i];

      if (city.roadLength[i] == 0 || dijkstra->visited[index]
          || dist >= dijkstra->distances[index]) {
        continue;
      }

      mapHeap[index].distanceToCity = dist;
      dijkstra->distances[index] = dist;
      Heap_Insert(&heap, mapHeap[index]);
    }
    dijkstra->visited[city.id] = true;
  }
  Heap_Destruct(&heap);

  return dijkstra->visited[destination];
}
