#include "heap.h"

#include "mymalloc.h"

#include <stdlib.h>
#include <string.h>

void Heap_Swap(tHeap *heap, size_t index1, size_t index2)
{
 if (heap == NULL || heap->array == NULL || index1 > heap->count || index2 > heap->count) {
   return;
 }

 Data_t tmp = heap->array[index1];
 heap->array[index1] = heap->array[index2];
 heap->array[index2] = tmp;
}

void Heap_Fix_Order(tHeap *heap, size_t index)
{
 size_t smallest = 0;
 size_t left, right;

 while (smallest < heap->count / 2) {
   left = 2 * smallest + 1;
   right = 2 * smallest + 2;

   if (left < heap->count && Data_Cmp(&heap->array[smallest], &heap->array[left]) > 0) {
     smallest = left;
   }

   if (right < heap->count && Data_Cmp(&heap->array[smallest], &heap->array[right]) > 0) {
     smallest = right;
   }

   if (smallest != index) {
     Heap_Swap(heap, smallest, index);
     index = smallest;
   } else
     break;
 }
}


bool Heap_Init(tHeap *heap)
{
 if (heap == NULL)
   return false;

 heap->count = 0;
 heap->maxItems = MAX_ITEMS_START;
 heap->array = myMalloc(MAX_ITEMS_START * sizeof(Data_t));

 if (heap->array == NULL)
   return false;

 return true;
}

bool Heap_Insert(tHeap *heap, Data_t insertData)
{
 if (heap == NULL)
   return false;

 if (heap->count + 1 > heap->maxItems) {
   Data_t *new = myRealloc(heap->array, heap->maxItems * sizeof(Data_t) * 2);

   if (new == NULL)
     return false;

   heap->array = new;
   heap->maxItems *= 2;
 }

 heap->array[heap->count] = insertData;
 heap->count++;

 for (size_t i = heap->count - 1; i > 0; --i) {
   if (Data_Cmp(&heap->array[(i - 1) / 2], &heap->array[i]) > 0) {
     Heap_Swap(heap, (i - 1) / 2, i);
   }
 }

 return true;
}

void Heap_Destruct(tHeap *heap)
{
 if (heap == NULL) {
   return;
 }

 myFree(heap->array);
 heap->array = NULL;
 heap->count = 0;
 heap->maxItems = 0;
}

bool Heap_FindMin(tHeap heap, Data_t *value)
{
 if (value == NULL || heap.count == 0)
   return false;
 *value = heap.array[0];
 return true;
}

bool Heap_DeleteMin(tHeap *heap, Data_t *deletedValue)
{
 if (heap == NULL || heap->count == 0) {
   return false;
 }

 if (deletedValue != NULL) {
   *deletedValue = heap->array[0];
 }

 if (heap->count == 1) {
   heap->count--;
   return true;
 }

 heap->array[0] = heap->array[heap->count - 1];
 heap->count--;
 Heap_Fix_Order(heap, 0);

 return true;
}

void Heap_Process(tHeap heap, heapProcessCB cb)
{
 if (cb == NULL)
   return;

 for (size_t i = 0; i < heap.count; ++i) {
   cb(i, &heap.array[i]);
 }
}

bool Heap_Empty(tHeap heap)
{
 if (heap.array == NULL || heap.count == 0)
   return true;
 return false;
}

unsigned Heap_Count(tHeap heap)
{
 return heap.count;
}
