/*!
* \file       FSM.c
* \author     Horak, Jurena
* \date       2019.6
* \brief      Implementace funkce z hlavičkového souboru FSM.h
* ******************************************
* \attention
* &copy; Copyright (c) 2022 FAI UTB. Všechna práva vyhrazena.
*
* Neoprávněné kopírování tohoto souboru jakýmkoliv způsobem je přísně zakázáno.
* Tento soubor je důvěrný a vlastnický.dadada
 */
/* Zahrnuté soubory ----------------------------------------------------------*/
#include "FSM.h"
#include <stdio.h>

typedef enum {NORMALNI, LOMITKO, RADKOVY, BLOKOVY, HVEZDICKA, RETEZEC, ZNAKOVA_KONSTANTA} FSM_Stav;

void FSM_RemoveNotes(FILE* input, FILE* output) {
  FSM_Stav state = NORMALNI;
  int znak;

  while ((znak = fgetc(input)) != EOF) {
    switch (state) {


      case NORMALNI:
        if (znak == '/') {
          state = LOMITKO;
        } else if (znak == '"') {
          fputc(znak, output);
          state = RETEZEC;
        } else if (znak == '\'') {
          fputc(znak, output);
          state = ZNAKOVA_KONSTANTA;
        } else {
          fputc(znak, output);
        }
        break;


      case LOMITKO:
        if (znak == '/') {
          state = RADKOVY;
        } else if (znak == '*') {
          state = BLOKOVY;
        } else {
          fputc('/', output);
          fputc(znak, output);
          state = NORMALNI;
        }
        break;


      case RADKOVY:
        if (znak == '\n') {
          fputc(znak, output);
          state = NORMALNI;
        }
        break;


      case BLOKOVY:
        if (znak == '*') {
          state = HVEZDICKA;
        }
        break;


      case HVEZDICKA:
        if (znak == '/') {
          state = NORMALNI;
        } else if (znak != '*') {
          state = BLOKOVY;
        }
        break;


      case RETEZEC:
        fputc(znak, output);
        if (znak == '"') {
          state = NORMALNI;
        } else if (znak == '\\') {
          fputc(fgetc(input), output);
        }
        break;


      case ZNAKOVA_KONSTANTA:
        fputc(znak, output);
        if (znak == '\'') {
          state = NORMALNI;
        } else if (znak == '\\') {
          fputc(fgetc(input), output);
        }
        break;
    }
  }
}
