#include <stdio.h>

int main( int argc, char **argv )
{
	const char* text3 = "This is a \" inside text with odd number ' ";

	return 0;
}
