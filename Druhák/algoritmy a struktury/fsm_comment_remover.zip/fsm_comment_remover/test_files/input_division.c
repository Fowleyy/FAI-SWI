#include <stdio.h>

int main( int argc, char **argv )
{
	double val = 10 / 2;

	return 0;
}
