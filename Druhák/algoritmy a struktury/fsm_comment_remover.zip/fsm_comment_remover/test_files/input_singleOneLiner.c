#include <stdio.h>
int main( int argc, char **argv )
{
	// One-line comment
	return 0;
}
