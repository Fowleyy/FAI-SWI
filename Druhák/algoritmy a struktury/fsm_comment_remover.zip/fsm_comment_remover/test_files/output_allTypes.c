

#include <stdio.h>


int main( int argc, char **argv )
{
	
	
	const char* text = "This is a /* comment */ inside 'text'";
	const char* text2 = "This is a // comment inside text"; 
	const char* text3 = "This is a \" inside text with odd number ' "; 
	
	char ch = '"';
	char ch2 = '\''; 
	char ch3 = '\\'; 
	
	double val = 10 / 2;
	
	return 0;
}
