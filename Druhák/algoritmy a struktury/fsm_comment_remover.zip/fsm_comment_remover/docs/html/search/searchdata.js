var indexSectionsWithContent =
{
  0: "cfmz",
  1: "c",
  2: "fm",
  3: "f",
  4: "f",
  5: "z"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "groups",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Modules",
  5: "Pages"
};

