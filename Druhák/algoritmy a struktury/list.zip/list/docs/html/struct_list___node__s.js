var struct_list___node__s =
[
    [ "data", "struct_list___node__s.html#a5a4fa152238036970f620343941e72c4", null ],
    [ "next", "struct_list___node__s.html#a512dc8c6be527ab6ea0e050ff8ff355f", null ]
];