var searchData=
[
  ['list_5fnode_5fptr_5ft_64',['List_Node_Ptr_t',['../group__list.html#gacf6bb6d04e407100c3f52f9836af1dab',1,'list.h']]],
  ['list_5fnode_5ft_65',['List_Node_t',['../group__list.html#ga6c765786e85f08f36b96f447a6343370',1,'list.h']]]
];
