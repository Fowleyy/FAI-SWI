var searchData=
[
  ['data_58',['data',['../struct_list___node__s.html#a5a4fa152238036970f620343941e72c4',1,'List_Node_s']]]
];
