#include <stdlib.h>
#include <string.h>
#include "vector.h"
#include "mymalloc.h"

Vector_t *Vector_Create(size_t initial_size, size_t alloc_step) {
    if (initial_size == 0 || alloc_step == 0) {
        return NULL;
    }

    Vector_t *vector = (Vector_t *)myMalloc(sizeof(Vector_t));
    if (!vector) {
        return NULL;
    }

    vector->items = (Vector_DataType_t *)myMalloc(initial_size * sizeof(Vector_DataType_t));
    if (!vector->items) {
        myFree(vector);
        return NULL;
    }

    vector->size = initial_size;
    vector->next = vector->items;
    vector->alloc_step = alloc_step;

    return vector;
}

Vector_t *Vector_Copy(const Vector_t *const original) {
    if (!original || !original->items) {
        return NULL;
    }

    size_t length = Vector_Length(original);
    Vector_t *copy = Vector_Create(original->size, original->alloc_step);
    if (!copy) {
        return NULL;
    }

    memcpy(copy->items, original->items, length * sizeof(Vector_DataType_t));
    copy->next = copy->items + length;

    return copy;
}

void Vector_Clear(Vector_t *const vector) {
    if (vector && vector->items) {
        myFree(vector->items);
        vector->items = NULL;
        vector->next = NULL;
        vector->size = 0;
    }
}

bool Vector_At(const Vector_t *const vector, size_t position, Vector_DataType_t *const value) {
    if (!vector || !vector->items || position >= Vector_Length(vector) || !value) {
        return false;
    }

    *value = vector->items[position];
    return true;
}

bool Vector_Remove(Vector_t *const vector, size_t position) {
    if (!vector || !vector->items || position >= Vector_Length(vector)) {
        return false;
    }

    memmove(&vector->items[position], &vector->items[position + 1],
            (Vector_Length(vector) - position - 1) * sizeof(Vector_DataType_t));

    vector->next--;
    return true;
}

size_t Vector_Length(const Vector_t *const vector) {
    if (vector == NULL) {
        return SIZE_MAX;
    }
    return vector->next - vector->items;
}

size_t Vector_Append(Vector_t *const vector, Vector_DataType_t value) {
    if (!vector || !vector->items) {
        return SIZE_MAX;
    }


    // Zkontroluj, zda je třeba alokovat více paměti
    if ((size_t)(vector->next - vector->items) >= vector->size) {
        size_t new_size = vector->size + vector->alloc_step;
        Vector_DataType_t *new_items = (Vector_DataType_t *)myRealloc(vector->items, new_size * sizeof(Vector_DataType_t));
        if (!new_items) {
            return SIZE_MAX;
        }

        vector->next = new_items + (vector->next - vector->items);
        vector->items = new_items;
        vector->size = new_size;
    }


    *vector->next = value;
    vector->next++;
    return Vector_Length(vector) - 1;
}

void Vector_Set(Vector_t *const vector, size_t position, Vector_DataType_t value) {
    if (vector && vector->items && position < Vector_Length(vector)) {
        vector->items[position] = value;
    }
}

bool Vector_Contains(const Vector_t *const vector, Vector_DataType_t value) {
    if (!vector || !vector->items) {
        return false;
    }

    for (size_t i = 0; i < Vector_Length(vector); i++) {
        if (vector->items[i] == value) {
            return true;
        }
    }

    return false;
}

size_t Vector_IndexOf(const Vector_t *const vector, Vector_DataType_t value, size_t from) {
    if (!vector || !vector->items || from >= Vector_Length(vector)) {
        return SIZE_MAX;
    }

    for (size_t i = from; i < Vector_Length(vector); i++) {
        if (vector->items[i] == value) {
            return i;
        }
    }

    return SIZE_MAX;
}

void Vector_Fill(const Vector_t *const vector, Vector_DataType_t value, size_t start_position, size_t end_position) {
    if (!vector || !vector->items || start_position >= Vector_Length(vector)) {
        return;
    }

    if (end_position >= Vector_Length(vector)) {
        end_position = Vector_Length(vector) - 1;
    }

    for (size_t i = start_position; i <= end_position; i++) {
        vector->items[i] = value;
    }
}

void Vector_Destroy(Vector_t **const vector) {
    if (vector && *vector) {
        if ((*vector)->items) {
            myFree((*vector)->items);
        }
        myFree(*vector);
        *vector = NULL;
    }
}
