var searchData=
[
  ['active_0',['active',['../struct_list__t.html#afe958fb464d8e90a2edd6498f8d1263f',1,'List_t']]],
  ['age_1',['age',['../struct_data__t.html#a1ee8d58aac49b258d938f5ec6a1a77f6',1,'Data_t']]],
  ['adt_20list_2',['ADT List',['../index.html',1,'']]]
];
