#include "./include/list.h"

#include <ctype.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


void List_Init(List_t *const list)
{
  if (list == NULL)
    return;

  list->first = NULL;
  list->active = NULL;
}

void List_Insert_First(List_t *const list, Data_t data)
{
  if (list == NULL)
    return;

  List_Node_t *node = myMalloc(sizeof(List_Node_t));
  if (node == NULL)
    return;

  node->data = data;
  node->next = list->first;
  list->first = node;
}

void List_First(List_t *const list)
{
  if (list == NULL) {
    return;
  }

  list->active = list->first;
}

bool List_Copy_First(List_t list, Data_t *data)
{
  if (data == NULL || list.first == NULL)
    return false;

  data->age = list.first->data.age;
  data->height = list.first->data.height;
  data->weight = list.first->data.weight;
  strcpy(data->name, list.first->data.name);

  return true;
}

void List_Delete_First(List_t *const list)
{
  if (list == NULL || list->first == NULL)
    return;

  if (list->first == list->active) {
    list->active = NULL;
  }

  List_Node_t *node = NULL;
  if (list->first->next != NULL) {
    node = list->first->next;
  }

  myFree(list->first);
  list->first = node;
}

void List_Post_Delete(List_t *const list)
{
  if (list == NULL || list->active == NULL || list->active->next == NULL)
    return;

  List_Node_t *link = list->active->next->next;
  myFree(list->active->next);
  list->active->next = link;
}

void List_Post_Insert(List_t *const list, Data_t data)
{
  if (list == NULL || list->active == NULL)
    return;

  List_Node_t *node = myMalloc(sizeof(List_Node_t));
  if (node == NULL)
    return;

  node->data = data;
  node->next = list->active->next;
  list->active->next = node;
}

bool List_Copy(List_t list, Data_t *data)
{
  if (data == NULL || list.active == NULL) {
    return false;
  }

  data->age = list.active->data.age;
  data->height = list.active->data.height;
  data->weight = list.active->data.weight;

  strcpy(data->name, list.active->data.name);

  return true;
}

void List_Active_Update(const List_t *const list, Data_t data)
{
  if (list == NULL || list->active == NULL)
    return;

  list->active->data = data;
}

void List_Active_Next(List_t *const list)
{
  if (list == NULL || list->active == NULL)
    return;

  list->active = list->active->next;
}

bool List_Is_Active(List_t list)
{
  return list.active != NULL;
}

void List_Reverse(List_t *list) {
  if (list == NULL || list->first == NULL) {
    return; // Pokud je seznam prázdný nebo neexistuje, neprováděj nic.
  }

  List_Node_t *prev = NULL;
  List_Node_t *current = list->first;
  List_Node_t *next = NULL;

  while (current != NULL) {
    next = current->next;  // Uložení následujícího uzlu
    current->next = prev;  // Reverzování směru ukazatele
    prev = current;        // Posunutí prev na aktuální uzel
    current = next;        // Posunutí current na další uzel
  }

  list->first = prev;  // Po skončení bude poslední uzel novým "prvním" uzlem
}