#include <stdlib.h>  // Include for malloc and free

void *myMalloc(size_t size) {
    return malloc(size);
}

void myFree(void *ptr) {
    free(ptr);
}
