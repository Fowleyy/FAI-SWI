var modules =
[
    [ "Data", "group__data.html", "group__data" ],
    [ "Binary tree", "group__tree.html", "group__tree" ]
];