var struct___tree_node =
[
    [ "data", "struct___tree_node.html#a5a4fa152238036970f620343941e72c4", null ],
    [ "left", "struct___tree_node.html#a6831b711549126d09b3bcc0a5118f0ef", null ],
    [ "right", "struct___tree_node.html#a35ed7d4b51469fa737bf8ac9d3493192", null ]
];