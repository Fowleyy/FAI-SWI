var searchData=
[
  ['binary_20tree_79',['Binary tree',['../group__tree.html',1,'']]]
];
