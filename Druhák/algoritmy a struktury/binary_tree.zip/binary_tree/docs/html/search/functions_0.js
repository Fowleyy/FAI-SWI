var searchData=
[
  ['data_5fcmp_49',['Data_Cmp',['../group__data.html#ga1dc4359e044d1e60c104ede24ab6fcae',1,'Data_Cmp(const Data_t *d1, const Data_t *d2):&#160;data.c'],['../group__data.html#ga1dc4359e044d1e60c104ede24ab6fcae',1,'Data_Cmp(const Data_t *d1, const Data_t *d2):&#160;data.c']]],
  ['data_5fget_50',['Data_Get',['../group__data.html#ga12e8f8f842613d3ec64e51f1b4165d11',1,'Data_Get(Data_t *data):&#160;data.c'],['../group__data.html#ga12e8f8f842613d3ec64e51f1b4165d11',1,'Data_Get(Data_t *data):&#160;data.c']]],
  ['data_5fprint_51',['Data_Print',['../group__data.html#ga8114b2217f1ee5e22d3da3f3d1a3b63a',1,'Data_Print(Data_t *data):&#160;data.c'],['../group__data.html#ga8114b2217f1ee5e22d3da3f3d1a3b63a',1,'Data_Print(Data_t *data):&#160;data.c']]]
];
