var searchData=
[
  ['name_66',['name',['../struct_data__t.html#a6db5324e662b3f6727875212f7aa6359',1,'Data_t']]],
  ['nodecount_67',['nodeCount',['../struct___tree.html#a7578e99b45e73434314682f5e67771c8',1,'_Tree']]]
];
