var searchData=
[
  ['binary_20tree_4',['Binary tree',['../group__tree.html',1,'']]],
  ['binární_20strom_5',['Binární strom',['../index.html',1,'']]]
];
