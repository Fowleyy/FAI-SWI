var searchData=
[
  ['binární_20strom_81',['Binární strom',['../index.html',1,'']]]
];
