var struct___tree =
[
    [ "nodeCount", "struct___tree.html#a7578e99b45e73434314682f5e67771c8", null ],
    [ "root", "struct___tree.html#a674753c8a07be3804c510c5a2a6e4aa6", null ]
];