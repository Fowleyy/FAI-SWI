#include "tree.h"
#include "data.h"
#include <stdlib.h>
#include <string.h>

#define SAFE_FREE(ptr) \
  do {                 \
    free(ptr);        \
    ptr = NULL;       \
  } while (0)

static TreeNode *TreeNode_Create(const Data_t data);
static void TreeNode_Destroy(TreeNode *node);
static void TreeNode_Process(TreeNode *node, TreeNodeProc proc, TreeProcessMode mode);

bool Tree_Init(Tree *const tree) {
  if (!tree) return false;
  tree->root = NULL;
  tree->nodeCount = 0;
  return true;
}

static void TreeNode_Destroy(TreeNode *node) {
  if (node) {
    TreeNode_Destroy(node->left);
    TreeNode_Destroy(node->right);
    SAFE_FREE(node);
  }
}

void Tree_Clear(Tree *const tree) {
  if (tree && tree->root) {
    TreeNode_Destroy(tree->root);
    tree->root = NULL;
    tree->nodeCount = 0;
  }
}

static TreeNode *TreeNode_Create(const Data_t data) {
  TreeNode *node = (TreeNode *)malloc(sizeof(TreeNode));
  if (!node) return NULL;
  node->data = data;
  node->left = NULL;
  node->right = NULL;
  return node;
}

bool Tree_Insert(Tree *const tree, const Data_t data) {
  if (!tree) return false;

  TreeNode *newNode = TreeNode_Create(data);
  if (!newNode) return false;

  if (!tree->root) {
    tree->root = newNode;
  } else {
    TreeNode *current = tree->root;
    TreeNode *parent = NULL;

    while (current) {
      parent = current;
      int cmp = Data_Cmp(&data, &current->data);

      if (cmp < 0) {
        current = current->left;
      } else if (cmp > 0) {
        current = current->right;
      } else {
        SAFE_FREE(newNode);
        return false;
      }
    }

    if (Data_Cmp(&data, &parent->data) < 0) {
      parent->left = newNode;
    } else {
      parent->right = newNode;
    }
  }

  tree->nodeCount++;
  return true;
}

TreeNode *Tree_Find_Node(Tree tree, const Data_t data) {
  TreeNode *current = tree.root;
  while (current) {
    int cmp = Data_Cmp(&data, &current->data);
    if (cmp == 0) {
      return current;
    } else if (cmp < 0) {
      current = current->left;
    } else {
      current = current->right;
    }
  }
  return NULL;
}

static TreeNode *TreeNode_Delete_Min(TreeNode *root, TreeNode **minNode) {
    if (!root) return NULL;

    if (root->left) {
        root->left = TreeNode_Delete_Min(root->left, minNode);
        return root;
    }

    *minNode = root;
    return root->right;
}

void Tree_Delete(Tree *const tree, const Data_t data) {
    if (!tree || !tree->root) return;

    TreeNode **current = &tree->root;

    while (*current && Data_Cmp(&(*current)->data, &data) != 0) {
        if (Data_Cmp(&data, &(*current)->data) < 0) {
            current = &(*current)->left;
        } else {
            current = &(*current)->right;
        }
    }

    if (*current) {
        TreeNode *nodeToDelete = *current;

        if (!nodeToDelete->left) {
            *current = nodeToDelete->right;
        } 
        else if (!nodeToDelete->right) {
            *current = nodeToDelete->left;
        } 
        else {
            TreeNode *minNode = NULL; 
            nodeToDelete->right = TreeNode_Delete_Min(nodeToDelete->right, &minNode);
            minNode->left = nodeToDelete->left;
            minNode->right = nodeToDelete->right;
            *current = minNode;
        }

        SAFE_FREE(nodeToDelete);
        tree->nodeCount--;
    }
}

size_t Tree_Get_Count(Tree tree) {
  return tree.nodeCount;
}

const Data_t *Tree_Get_Data(const TreeNode *const node) {
  return node ? &node->data : NULL;
}

static void TreeNode_Process(TreeNode *node, TreeNodeProc proc, TreeProcessMode mode) {
  if (!node || !proc) return;

  if (mode == PRE_ORDER) proc(node);
  
  TreeNode_Process(node->left, proc, mode);
  
  if (mode == IN_ORDER) proc(node);
  
  TreeNode_Process(node->right, proc, mode);
  
  if (mode == POST_ORDER) proc(node);
}

void Tree_Process(Tree tree, TreeNodeProc proc, TreeProcessMode mode) {
  TreeNode_Process(tree.root, proc, mode);
}