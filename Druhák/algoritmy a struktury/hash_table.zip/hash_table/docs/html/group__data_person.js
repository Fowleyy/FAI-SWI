var group__data_person =
[
    [ "Data_Person_t", "struct_data___person__t.html", [
      [ "age", "struct_data___person__t.html#a1ee8d58aac49b258d938f5ec6a1a77f6", null ],
      [ "fncs", "struct_data___person__t.html#a5c15801cccd76a5e6a90aa1a689b83eb", null ],
      [ "height", "struct_data___person__t.html#a89f6abd564014faeff7cd20c340a9c7d", null ],
      [ "name", "struct_data___person__t.html#a6db5324e662b3f6727875212f7aa6359", null ],
      [ "weight", "struct_data___person__t.html#a99108733d00274978a4979dc072bd513", null ]
    ] ],
    [ "Data_Person_Create", "group__data_person.html#ga7c6e22b921fd23961ce8263977295d9f", null ],
    [ "Data_Person_Init", "group__data_person.html#ga6d232a175994ba12c65813d7cbd6f067", null ],
    [ "Data_Person_New", "group__data_person.html#ga060308539d07da7edd68d24bbb67e05d", null ]
];