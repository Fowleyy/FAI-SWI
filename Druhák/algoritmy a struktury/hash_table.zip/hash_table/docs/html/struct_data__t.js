var struct_data__t =
[
    [ "data", "struct_data__t.html#a735984d41155bc1032e09bece8f8d66d", null ],
    [ "fncs", "struct_data__t.html#a5c15801cccd76a5e6a90aa1a689b83eb", null ]
];