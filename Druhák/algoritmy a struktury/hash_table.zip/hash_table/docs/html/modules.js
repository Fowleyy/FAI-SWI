var modules =
[
    [ "Abstract data type", "group__data.html", "group__data" ],
    [ "Hash table", "group__hash_table.html", "group__hash_table" ]
];