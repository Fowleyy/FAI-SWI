var annotated_dup =
[
    [ "_HashTable", "struct___hash_table.html", "struct___hash_table" ],
    [ "_HashTableNode", "struct___hash_table_node.html", "struct___hash_table_node" ],
    [ "Data_Cstring_t", "struct_data___cstring__t.html", "struct_data___cstring__t" ],
    [ "Data_Functions_t", "struct_data___functions__t.html", "struct_data___functions__t" ],
    [ "Data_Person_t", "struct_data___person__t.html", "struct_data___person__t" ],
    [ "Data_t", "struct_data__t.html", "struct_data__t" ]
];