var struct_data___person__t =
[
    [ "age", "struct_data___person__t.html#a1ee8d58aac49b258d938f5ec6a1a77f6", null ],
    [ "fncs", "struct_data___person__t.html#a5c15801cccd76a5e6a90aa1a689b83eb", null ],
    [ "height", "struct_data___person__t.html#a89f6abd564014faeff7cd20c340a9c7d", null ],
    [ "name", "struct_data___person__t.html#a6db5324e662b3f6727875212f7aa6359", null ],
    [ "weight", "struct_data___person__t.html#a99108733d00274978a4979dc072bd513", null ]
];