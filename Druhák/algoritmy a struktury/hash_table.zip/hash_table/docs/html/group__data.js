var group__data =
[
    [ "Ukázka běhu programu/Example of program:", "index.html#autotoc_md5", null ],
    [ "Data C-String", "group__data_cstring.html", "group__data_cstring" ],
    [ "Data person", "group__data_person.html", "group__data_person" ],
    [ "Data_Functions_t", "struct_data___functions__t.html", [
      [ "cmp", "struct_data___functions__t.html#adf3e2387a127666ab57c991b61b8c1f5", null ],
      [ "destruct", "struct_data___functions__t.html#a04c95b43f658a3b856b2b2a097caf4df", null ],
      [ "from_string", "struct_data___functions__t.html#a4833f23d6c1304f225cf06dfef938441", null ],
      [ "get_type", "struct_data___functions__t.html#aaace8d2fe287b9fed2a2dc681b3e5174", null ],
      [ "hash", "struct_data___functions__t.html#a2df4c92e491fbc8fa0b99576cc0bf55f", null ],
      [ "to_string", "struct_data___functions__t.html#a166b720c9b258cfb95b41d788080437f", null ]
    ] ],
    [ "Data_t", "struct_data__t.html", [
      [ "data", "struct_data__t.html#a735984d41155bc1032e09bece8f8d66d", null ],
      [ "fncs", "struct_data__t.html#a5c15801cccd76a5e6a90aa1a689b83eb", null ]
    ] ],
    [ "__attribute__", "group__data.html#ga0de5cafc75d962810fcf1ffec4a37126", null ],
    [ "Data_Cmp", "group__data.html#ga51c812529667850d5944f28a82c14d97", null ],
    [ "Data_From_String", "group__data.html#ga8b4f6d05a6824842e26a1280e793bc4f", null ],
    [ "Data_Get_Type", "group__data.html#ga930eb1f8a04338588b016e61dfaba241", null ],
    [ "Data_Hash", "group__data.html#gacad203914a0595adaabb73621c26c340", null ],
    [ "Data_To_String", "group__data.html#gaf10c107718ef95982b3b1b66934f79dc", null ]
];