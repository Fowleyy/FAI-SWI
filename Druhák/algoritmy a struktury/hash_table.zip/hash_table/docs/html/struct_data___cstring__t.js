var struct_data___cstring__t =
[
    [ "cstring", "struct_data___cstring__t.html#a98b47da1ae38426607691550dd4c83f3", null ],
    [ "fncs", "struct_data___cstring__t.html#a5c15801cccd76a5e6a90aa1a689b83eb", null ]
];