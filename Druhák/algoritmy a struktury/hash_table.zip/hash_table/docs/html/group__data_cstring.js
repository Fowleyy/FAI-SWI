var group__data_cstring =
[
    [ "Data_Cstring_t", "struct_data___cstring__t.html", [
      [ "cstring", "struct_data___cstring__t.html#a98b47da1ae38426607691550dd4c83f3", null ],
      [ "fncs", "struct_data___cstring__t.html#a5c15801cccd76a5e6a90aa1a689b83eb", null ]
    ] ],
    [ "Data_Cstring_Create", "group__data_cstring.html#gaaef704246aa9609197fe14be4c1f8583", null ],
    [ "Data_Cstring_Init", "group__data_cstring.html#ga952aea6441b9bf857a555235f75a058d", null ],
    [ "Data_Cstring_New", "group__data_cstring.html#ga8eb7b3725d895cf558c101bfcd34c2d7", null ]
];