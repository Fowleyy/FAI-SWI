var data__person_8h =
[
    [ "Data_Person_Create", "group__data_person.html#ga7c6e22b921fd23961ce8263977295d9f", null ],
    [ "Data_Person_Init", "group__data_person.html#ga6d232a175994ba12c65813d7cbd6f067", null ],
    [ "Data_Person_New", "group__data_person.html#ga060308539d07da7edd68d24bbb67e05d", null ]
];