var searchData=
[
  ['data_5fcstring_5ft_70',['Data_Cstring_t',['../struct_data___cstring__t.html',1,'']]],
  ['data_5ffunctions_5ft_71',['Data_Functions_t',['../struct_data___functions__t.html',1,'']]],
  ['data_5fperson_5ft_72',['Data_Person_t',['../struct_data___person__t.html',1,'']]],
  ['data_5ft_73',['Data_t',['../struct_data__t.html',1,'']]]
];
