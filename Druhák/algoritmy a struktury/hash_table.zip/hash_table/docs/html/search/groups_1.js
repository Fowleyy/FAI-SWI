var searchData=
[
  ['data_20c_2dstring_133',['Data C-String',['../group__data_cstring.html',1,'']]],
  ['data_20person_134',['Data person',['../group__data_person.html',1,'']]]
];
