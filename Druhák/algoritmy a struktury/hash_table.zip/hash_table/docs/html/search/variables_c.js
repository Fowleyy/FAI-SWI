var searchData=
[
  ['weight_128',['weight',['../struct_data___person__t.html#a99108733d00274978a4979dc072bd513',1,'Data_Person_t']]]
];
