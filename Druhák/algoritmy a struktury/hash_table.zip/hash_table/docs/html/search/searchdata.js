var indexSectionsWithContent =
{
  0: "_abcdfghkmnpstvw",
  1: "_d",
  2: "dhmt",
  3: "_dhmp",
  4: "abcdfghknstvw",
  5: "ht",
  6: "adh",
  7: "h"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "groups",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Modules",
  7: "Pages"
};

