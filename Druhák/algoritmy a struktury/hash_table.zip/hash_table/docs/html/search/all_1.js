var searchData=
[
  ['age_3',['age',['../struct_data___person__t.html#a1ee8d58aac49b258d938f5ec6a1a77f6',1,'Data_Person_t']]],
  ['abstract_20data_20type_4',['Abstract data type',['../group__data.html',1,'']]]
];
