var searchData=
[
  ['name_57',['name',['../struct_data___person__t.html#a6db5324e662b3f6727875212f7aa6359',1,'Data_Person_t']]],
  ['next_58',['next',['../struct___hash_table_node.html#a4da6de1273cb4681094c1d384b001d58',1,'_HashTableNode']]]
];
