var searchData=
[
  ['data_114',['data',['../struct_data__t.html#a735984d41155bc1032e09bece8f8d66d',1,'Data_t']]],
  ['destruct_115',['destruct',['../struct_data___functions__t.html#a04c95b43f658a3b856b2b2a097caf4df',1,'Data_Functions_t']]]
];
