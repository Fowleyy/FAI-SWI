var searchData=
[
  ['abstract_20data_20type_132',['Abstract data type',['../group__data.html',1,'']]]
];
