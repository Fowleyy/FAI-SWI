var searchData=
[
  ['fncs_34',['fncs',['../struct_data__t.html#a5c15801cccd76a5e6a90aa1a689b83eb',1,'Data_t::fncs()'],['../struct_data___cstring__t.html#a5c15801cccd76a5e6a90aa1a689b83eb',1,'Data_Cstring_t::fncs()'],['../struct_data___person__t.html#a5c15801cccd76a5e6a90aa1a689b83eb',1,'Data_Person_t::fncs()']]],
  ['from_5fstring_35',['from_string',['../struct_data___functions__t.html#a4833f23d6c1304f225cf06dfef938441',1,'Data_Functions_t']]]
];
