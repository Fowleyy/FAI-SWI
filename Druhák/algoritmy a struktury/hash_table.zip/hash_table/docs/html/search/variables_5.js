var searchData=
[
  ['get_5ftype_118',['get_type',['../struct_data___functions__t.html#aaace8d2fe287b9fed2a2dc681b3e5174',1,'Data_Functions_t']]]
];
