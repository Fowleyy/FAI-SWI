/*!
* \file       table.c
* \author     Ondřej Ševčík
* \date       6/2019
* \brief      Implementation of functions for HashTable.
* **************************************************************
* \attention
* &copy; Copyright (c) 2022 FAI UTB. All rights reserved.
*
* Unauthorized copying of this file, via any medium is strictly prohibited
* Proprietary and confidential
*/
/*! \addtogroup hashTable
*  \{
*/
/* Includes --------------------------------------------------------------------------------------*/
#include "table.h"

#include "hash_private.h"
#include "mymalloc.h"

#include <stdio.h>
#include <string.h>

/* Private types ---------------------------------------------------------------------------------*/
/* Private macros --------------------------------------------------------------------------------*/
#define UNUSED(x) (void)x

/* Private variables -----------------------------------------------------------------------------*/
/* Private function declarations -----------------------------------------------------------------*/
/* Exported functions definitions ----------------------------------------------------------------*/
bool HashTable_Init(HashTable *table, size_t size, bool deletecontents)
{
 if(table == NULL){
   return false;
 }

 table->take_ownership = deletecontents;
 table->size = size;
 table->count = 0;
 table->buckets = myMalloc(size * sizeof(size_t));
 if(table->buckets == NULL){
   return false;
 }

 for(size_t i = 0; i < size; i++){
   table->buckets[i] = NULL;
 }

 return true;
}

void HashTable_Destruct(HashTable *table)
{
 if(table == NULL){
   return;
 }

 table->count = 0;
 table->size = 0;
 myFree(table->buckets);
 table->buckets = NULL;
}

bool HashTable_Insert(HashTable *table, Data_t *key, Data_t *value)
{
 if(table == NULL  || key == NULL || value == NULL){
   return false;
 }

 size_t i = hash(table, key);
 HashTableNode* node = table->buckets[i];
 if(node == NULL){
   table->buckets[i] = myMalloc(sizeof(HashTableNode));
   if(table->buckets[i] == NULL){
     return false;
   }
   table->buckets[i]->value = value;
   table->buckets[i]->key = key;
   table->buckets[i]->next = NULL;
   table->count++;
   return true;
 }else{
   while(node != NULL){
     if(Data_Cmp(key, node->key) == 0){
       return false;
     }
     node = node->next;
   }
   HashTableNode* newNode = myMalloc(sizeof(HashTableNode));
   if(newNode == NULL){
     return false;
   }
   newNode->key = key;
   newNode->value = value;
   newNode->next = table->buckets[i];
   table->buckets[i] = newNode;
   table->count++;
   return true;
 }
}

bool HashTable_Replace(HashTable *table, Data_t *key, Data_t *value)
{
 if(table == NULL || key == NULL){
   return false;
 }

 for(size_t i = 0; i < table->size; i++){
   HashTableNode* node = table->buckets[i];
   while(node != NULL){
     HashTableNode* next = node->next;
     if(Data_Cmp(node->key, key) == 0){
       if(table->take_ownership){
         Data_Destruct(node->value);
       }
       node->value = value;
       return true;
     }
     node = next;
   }
 }

 return false;
}

bool HashTable_Delete(HashTable *table, Data_t *key)
{
 if(table == NULL || key == NULL){
   return false;
 }

 for(size_t i = 0; i < table->size; i++){
   HashTableNode* node = table->buckets[i];
   HashTableNode* prev = NULL;
   while(node != NULL){
     HashTableNode* next = node->next;
     if(Data_Cmp(node->key, key) == 0){
       if(table->take_ownership) {
         Data_Destruct(node->value);
       }
       Data_Destruct(node->key);
       myFree(node);
       node = NULL;
       if(prev != NULL){
         prev->next = next;
       }else{
         table->buckets[i] = NULL;
       }
       table->count--;
       return true;
     }
     prev = node;
     node = next;
   }
   prev = NULL;
 }

 return false;
}

Data_t *HashTable_Find(HashTable *table, Data_t *key)
{
 if(table == NULL || key == NULL){
   return false;
 }

 for(size_t i = 0; i < table->size; i++){
   HashTableNode* node = table->buckets[i];
   while(node != NULL){
     HashTableNode* next = node->next;
     if(Data_Cmp(node->key, key) == 0){
       return node->value;
     }
     node = next;
   }
 }

 return NULL;
}

size_t HashTable_Get_Count(HashTable table)
{
 return table.count;
}

void HashTable_Clear(HashTable *table)
{
 if(table == NULL){
   return;
 }

 for(size_t i = 0; i < table->size; i++){
   HashTableNode* node = table->buckets[i];
   while(node != NULL){
     HashTableNode* next = node->next;

     Data_Destruct(node->key);
     if(table->take_ownership){
       Data_Destruct(node->value);
     }
     myFree(node);
     node = next;
   }
   table->buckets[i] = NULL;
 }

 table->count = 0;
}

void HashTable_Process(HashTable *table, TableNodeProc proc)
{
 if(table == NULL || proc == NULL){
   return;
 }

 for(size_t i = 0; i < table->size; i++){
   HashTableNode* node = table->buckets[i];
   while(node != NULL){
     proc(node->key, node->value);
     node = node->next;
   }
 }
}

/* Private function definitions ------------------------------------------------------------------*/

/*! \} */