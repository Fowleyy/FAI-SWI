#include "heap.h"
#include <stdlib.h>
#include <stdio.h>
 
bool Heap_Init(tHeap *heap) {
    if (!heap) return false;
 
    heap->array = malloc(MAX_ITEMS_START * sizeof(Data_t));
    if (!heap->array) {
        return false;
    }
 
    heap->count = 0;
    heap->maxItems = MAX_ITEMS_START;
    printf("myMalloc: allocating %zu bytes, memory allocated %zu bytes\n", 
           MAX_ITEMS_START * sizeof(Data_t), MAX_ITEMS_START * sizeof(Data_t)); 
 
    return true;
}
 
bool Heap_Insert(tHeap *heap, Data_t insertData) {
    if (!heap) return false;
 
    if (heap->count >= heap->maxItems) {
        size_t oldSize = heap->maxItems * sizeof(Data_t);
        size_t newSize = oldSize + (MAX_ITEMS_START * sizeof(Data_t)); 
        Data_t *newArray = realloc(heap->array, newSize);
        if (!newArray) {
            return false;
        }
        heap->array = newArray;
        heap->maxItems *= 2;  
 
        printf("myRealloc: allocating %zu bytes, memory allocated %zu bytes\n",
               MAX_ITEMS_START * sizeof(Data_t), heap->maxItems * sizeof(Data_t));
    }
 
    size_t i = heap->count++;
    while (i > 0) {
        size_t parent = (i - 1) / 2;
        if (Data_Cmp(&heap->array[parent], &insertData) <= 0) break;
        heap->array[i] = heap->array[parent];
        i = parent;
    }
    heap->array[i] = insertData;
    return true;
}
 
void Heap_Destruct(tHeap *heap) {
    if (heap) {
        printf("myFree: releasing %zu bytes, memory allocated %zu bytes\n", 
               heap->maxItems * sizeof(Data_t), (size_t)0); 
        free(heap->array);
        heap->array = NULL;
        heap->count = 0;
        heap->maxItems = 0;
    }
}
 
 
 
bool Heap_FindMin(tHeap heap, Data_t *value) {
    if (heap.count == 0) return false;
 
    if (value) {
        *value = heap.array[0];
    }
    return true;
}
 
 
bool Heap_DeleteMin(tHeap *heap, Data_t *deletedValue) {
    if (!heap || heap->count == 0) return false;
 
    if (deletedValue) {
        *deletedValue = heap->array[0];
    }
 
    Data_t temp = heap->array[--(heap->count)];
    size_t i = 0;
    while (2 * i + 1 < heap->count) {
        size_t leftChild = 2 * i + 1;
        size_t rightChild = leftChild + 1;
        size_t minChild = leftChild;
 
        if (rightChild < heap->count && Data_Cmp(&heap->array[rightChild], &heap->array[leftChild]) < 0) {
            minChild = rightChild;
        }
 
        if (Data_Cmp(&temp, &heap->array[minChild]) <= 0) break;
 
        heap->array[i] = heap->array[minChild];
        i = minChild;
    }
    heap->array[i] = temp;
    return true;
}
 
 
bool Heap_Empty(tHeap heap) {
    return heap.count == 0;
}
 
 
unsigned int Heap_Count(tHeap heap) {
    return heap.count;
}
 
 
void Heap_Process(tHeap heap, heapProcessCB cb) {
    if (cb) {
        for (size_t i = 0; i < heap.count; ++i) {
            cb(i, &heap.array[i]);
        }
    }
}