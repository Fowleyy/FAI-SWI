var searchData=
[
  ['name_52',['name',['../struct_data__t.html#a6db5324e662b3f6727875212f7aa6359',1,'Data_t']]]
];
