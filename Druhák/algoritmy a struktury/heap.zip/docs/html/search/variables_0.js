var searchData=
[
  ['age_47',['age',['../struct_data__t.html#a1ee8d58aac49b258d938f5ec6a1a77f6',1,'Data_t']]],
  ['array_48',['array',['../structt_heap.html#acf614b8326962d72a866226da9c194d8',1,'tHeap']]]
];
