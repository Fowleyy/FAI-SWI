var searchData=
[
  ['data_5fcmp_36',['Data_Cmp',['../group__data.html#ga1dc4359e044d1e60c104ede24ab6fcae',1,'Data_Cmp(const Data_t *d1, const Data_t *d2):&#160;data.c'],['../group__data.html#ga1dc4359e044d1e60c104ede24ab6fcae',1,'Data_Cmp(const Data_t *d1, const Data_t *d2):&#160;data.c']]],
  ['data_5fget_37',['Data_Get',['../group__data.html#ga12e8f8f842613d3ec64e51f1b4165d11',1,'Data_Get(Data_t *data):&#160;data.c'],['../group__data.html#ga12e8f8f842613d3ec64e51f1b4165d11',1,'Data_Get(Data_t *data):&#160;data.c']]],
  ['data_5fprint_38',['Data_Print',['../group__data.html#ga1a7ac52023e6fbb090aeae986ff3cdfa',1,'Data_Print(const Data_t *data):&#160;data.c'],['../group__data.html#ga1a7ac52023e6fbb090aeae986ff3cdfa',1,'Data_Print(const Data_t *data):&#160;data.c']]]
];
