var indexSectionsWithContent =
{
  0: "acdhmntw",
  1: "dt",
  2: "dhm",
  3: "dh",
  4: "achmnw",
  5: "dh",
  6: "h"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "groups",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Modules",
  6: "Pages"
};

