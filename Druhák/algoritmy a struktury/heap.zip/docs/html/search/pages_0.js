var searchData=
[
  ['halda_56',['HALDA',['../index.html',1,'']]]
];
